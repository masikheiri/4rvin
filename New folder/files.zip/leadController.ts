import { Request, Response } from 'express';
import {
  createLeadWithProject,
  getAllLeads,
  getRevenueSummary,
  updateProjectStatus,
  RenovationLead,
} from '../models/leadModel';

// ── Validation helpers ──────────────────────────────────────
const EMAIL_RE   = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE   = /^[\d\s\-\+\(\)]{7,20}$/;
const POSTAL_RE  = /^[A-Za-z]\d[A-Za-z][ ]?\d[A-Za-z]\d$/; // Canadian postal

const VALID_SCOPES = [
  'Drywall & Gypsum',
  'Flooring & Epoxy',
  'Premium Painting',
  'Complete Interior Turnkey',
] as const;

const VALID_TYPES = ['Commercial', 'Residential'] as const;

function validateLead(body: any): string[] {
  const errors: string[] = [];

  if (!body.contactName?.trim())           errors.push('contactName is required');
  if (!EMAIL_RE.test(body.contactEmail))   errors.push('contactEmail is invalid');
  if (!PHONE_RE.test(body.contactPhone))   errors.push('contactPhone is invalid');
  if (!POSTAL_RE.test(body.postalCode))    errors.push('postalCode must be a valid Canadian postal code');
  if (!VALID_SCOPES.includes(body.scopeSelection))
                                           errors.push(`scopeSelection must be one of: ${VALID_SCOPES.join(', ')}`);
  if (!VALID_TYPES.includes(body.projectType))
                                           errors.push(`projectType must be Commercial or Residential`);

  const sqft = Number(body.squareFootage);
  if (isNaN(sqft) || sqft < 500 || sqft > 50_000)
    errors.push('squareFootage must be between 500 and 50,000');

  return errors;
}

// ── POST /api/leads ──────────────────────────────────────────
export const handleLeadSubmission = async (req: Request, res: Response) => {
  const errors = validateLead(req.body);
  if (errors.length) {
    return res.status(400).json({ success: false, errors });
  }

  const lead: RenovationLead = {
    ...req.body,
    squareFootage: Number(req.body.squareFootage),
    ipAddress:     req.ip,
    userAgent:     req.headers['user-agent'],
  };

  try {
    const result = await createLeadWithProject(lead);
    return res.status(201).json({
      success: true,
      message: 'Lead registered and estimate generated.',
      data: result,
    });
  } catch (err: any) {
    // Duplicate submission within same day
    if (err.code === '23505') {
      return res.status(409).json({
        success: false,
        errors: ['An estimate for this email was already submitted today. Please contact us directly.'],
      });
    }
    console.error('[leadController] DB error:', err);
    return res.status(500).json({ success: false, errors: ['Internal server error.'] });
  }
};

// ── GET /api/leads ───────────────────────────────────────────
export const handleGetLeads = async (_req: Request, res: Response) => {
  try {
    const leads = await getAllLeads();
    return res.json({ success: true, data: leads });
  } catch (err) {
    console.error('[leadController] getAllLeads error:', err);
    return res.status(500).json({ success: false, errors: ['Failed to fetch leads.'] });
  }
};

// ── GET /api/leads/summary ───────────────────────────────────
export const handleGetSummary = async (_req: Request, res: Response) => {
  try {
    const summary = await getRevenueSummary();
    return res.json({ success: true, data: summary });
  } catch (err) {
    console.error('[leadController] getRevenueSummary error:', err);
    return res.status(500).json({ success: false, errors: ['Failed to fetch summary.'] });
  }
};

// ── PATCH /api/projects/:id/status ──────────────────────────
export const handleUpdateStatus = async (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;

  const VALID_STATUSES = [
    'Lead_Generated', 'Estimate_Sent', 'In_Review',
    'Proposal_Accepted', 'In_Progress', 'Completed', 'Cancelled',
  ];

  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ success: false, errors: [`Invalid status: ${status}`] });
  }

  try {
    const updated = await updateProjectStatus(id, status);
    if (!updated) return res.status(404).json({ success: false, errors: ['Project not found.'] });
    return res.json({ success: true, data: updated });
  } catch (err) {
    console.error('[leadController] updateStatus error:', err);
    return res.status(500).json({ success: false, errors: ['Failed to update status.'] });
  }
};
