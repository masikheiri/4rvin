import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import { pool } from './config/database';
import apiRoutes from './routes/api';
import { requestLogger, errorHandler } from './middleware/middleware';

const app  = express();
const PORT = Number(process.env.PORT) || 5000;

// ── Security & parsing ──────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin:      process.env.FRONTEND_URL ?? 'http://localhost:3000',
  credentials: true,
}));
app.use(compression());
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false }));

// ── Logging ─────────────────────────────────────────────────
app.use(requestLogger);

// ── Routes ──────────────────────────────────────────────────
app.use('/api', apiRoutes);

// ── 404 catch-all ───────────────────────────────────────────
app.use((_req, res) => res.status(404).json({ success: false, errors: ['Route not found.'] }));

// ── Global error handler ────────────────────────────────────
app.use(errorHandler);

// ── DB connectivity check + server start ────────────────────
async function bootstrap() {
  try {
    const client = await pool.connect();
    await client.query('SELECT 1');
    client.release();
    console.log('✅  PostgreSQL connected');

    app.listen(PORT, () => {
      console.log(`🚀  Server running on http://localhost:${PORT}`);
      console.log(`    ENV: ${process.env.NODE_ENV ?? 'development'}`);
    });
  } catch (err) {
    console.error('❌  Failed to connect to PostgreSQL:', err);
    process.exit(1);
  }
}

bootstrap();

export default app;
