-- ============================================================
--  INTERIOR RENOVATION PLATFORM — PostgreSQL Schema
--  Compatible with PostgreSQL 14+
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
--  ENUM TYPES
-- ============================================================
CREATE TYPE project_type   AS ENUM ('Commercial', 'Residential');
CREATE TYPE project_status AS ENUM (
  'Lead_Generated',
  'Estimate_Sent',
  'In_Review',
  'Proposal_Accepted',
  'In_Progress',
  'Completed',
  'Cancelled'
);
CREATE TYPE scope_type AS ENUM (
  'Drywall & Gypsum',
  'Flooring & Epoxy',
  'Premium Painting',
  'Complete Interior Turnkey'
);

-- ============================================================
--  RENOVATION PROJECTS
-- ============================================================
CREATE TABLE RenovationProjects (
  ProjectID       UUID            DEFAULT uuid_generate_v4() PRIMARY KEY,
  ProjectName     VARCHAR(255)    NOT NULL,
  ProjectType     project_type    NOT NULL,
  ScopeType       scope_type      NOT NULL,
  SquareFootage   INTEGER         NOT NULL CHECK (SquareFootage BETWEEN 500 AND 50000),
  EstimatedCost   NUMERIC(12, 2)  NOT NULL,
  FinalCost       NUMERIC(12, 2),
  Status          project_status  NOT NULL DEFAULT 'Lead_Generated',
  CreatedAt       TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  UpdatedAt       TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_projects_status    ON RenovationProjects(Status);
CREATE INDEX idx_projects_type      ON RenovationProjects(ProjectType);
CREATE INDEX idx_projects_created   ON RenovationProjects(CreatedAt DESC);

-- ============================================================
--  LEAD SUBMISSIONS
-- ============================================================
CREATE TABLE LeadSubmissions (
  LeadID          UUID            DEFAULT uuid_generate_v4() PRIMARY KEY,
  ProjectID       UUID            NOT NULL REFERENCES RenovationProjects(ProjectID) ON DELETE CASCADE,
  CompanyName     VARCHAR(255),
  ContactName     VARCHAR(255)    NOT NULL,
  ContactEmail    VARCHAR(255)    NOT NULL,
  ContactPhone    VARCHAR(50)     NOT NULL,
  PostalCode      VARCHAR(20)     NOT NULL,
  Notes           TEXT,
  IPAddress       INET,
  UserAgent       TEXT,
  SubmittedAt     TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_leads_project      ON LeadSubmissions(ProjectID);
CREATE INDEX idx_leads_email        ON LeadSubmissions(ContactEmail);
CREATE INDEX idx_leads_submitted    ON LeadSubmissions(SubmittedAt DESC);

-- Prevent duplicate email submissions within 24h for the same scope
CREATE UNIQUE INDEX idx_leads_dedup
  ON LeadSubmissions(ContactEmail, SubmittedAt::DATE);

-- ============================================================
--  COST RATE TABLE (for dynamic pricing logic)
-- ============================================================
CREATE TABLE CostRates (
  RateID          SERIAL          PRIMARY KEY,
  ScopeType       scope_type      NOT NULL,
  ProjectType     project_type    NOT NULL,
  RatePerSqft     NUMERIC(8, 2)   NOT NULL,
  EffectiveFrom   DATE            NOT NULL DEFAULT CURRENT_DATE,
  EffectiveTo     DATE,
  UNIQUE (ScopeType, ProjectType, EffectiveFrom)
);

-- Seed default rates (CAD per sqft)
INSERT INTO CostRates (ScopeType, ProjectType, RatePerSqft) VALUES
  ('Drywall & Gypsum',           'Commercial',  85.00),
  ('Drywall & Gypsum',           'Residential', 70.00),
  ('Flooring & Epoxy',           'Commercial', 110.00),
  ('Flooring & Epoxy',           'Residential', 90.00),
  ('Premium Painting',           'Commercial',  65.00),
  ('Premium Painting',           'Residential', 55.00),
  ('Complete Interior Turnkey',  'Commercial', 195.00),
  ('Complete Interior Turnkey',  'Residential',165.00);

-- ============================================================
--  AUTO-UPDATE UpdatedAt TRIGGER
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.UpdatedAt = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_projects_updated
  BEFORE UPDATE ON RenovationProjects
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
--  HELPFUL VIEWS
-- ============================================================

-- Full lead + project joined view (for admin dashboard)
CREATE VIEW v_lead_overview AS
SELECT
  l.LeadID,
  l.SubmittedAt,
  l.ContactName,
  l.ContactEmail,
  l.ContactPhone,
  l.CompanyName,
  l.PostalCode,
  p.ProjectID,
  p.ProjectName,
  p.ProjectType,
  p.ScopeType,
  p.SquareFootage,
  p.EstimatedCost,
  p.Status
FROM LeadSubmissions l
JOIN RenovationProjects p ON p.ProjectID = l.ProjectID
ORDER BY l.SubmittedAt DESC;

-- Revenue funnel summary
CREATE VIEW v_revenue_summary AS
SELECT
  Status,
  COUNT(*)                          AS ProjectCount,
  SUM(EstimatedCost)                AS TotalEstimated,
  AVG(EstimatedCost)                AS AvgEstimated,
  SUM(FinalCost)                    AS TotalActual
FROM RenovationProjects
GROUP BY Status
ORDER BY MIN(CreatedAt);

-- ============================================================
--  SEED DATA — sample leads for dev/staging
-- ============================================================
DO $$
DECLARE
  p1 UUID; p2 UUID; p3 UUID;
BEGIN
  INSERT INTO RenovationProjects (ProjectName, ProjectType, ScopeType, SquareFootage, EstimatedCost, Status)
    VALUES ('Tremaine Group - Complete Interior Turnkey', 'Commercial', 'Complete Interior Turnkey', 4200, 819000.00, 'Proposal_Accepted')
    RETURNING ProjectID INTO p1;
  INSERT INTO LeadSubmissions (ProjectID, CompanyName, ContactName, ContactEmail, ContactPhone, PostalCode)
    VALUES (p1, 'Tremaine Group', 'Sarah Tremaine', 'sarah@tremainegroup.ca', '514-882-3301', 'H3A 2T5');

  INSERT INTO RenovationProjects (ProjectName, ProjectType, ScopeType, SquareFootage, EstimatedCost, Status)
    VALUES ('Okafor Residence - Flooring & Epoxy', 'Residential', 'Flooring & Epoxy', 2100, 189000.00, 'Estimate_Sent')
    RETURNING ProjectID INTO p2;
  INSERT INTO LeadSubmissions (ProjectID, ContactName, ContactEmail, ContactPhone, PostalCode)
    VALUES (p2, 'Marcus Okafor', 'marcus.okafor@gmail.com', '438-501-7744', 'H2X 1Y3');

  INSERT INTO RenovationProjects (ProjectName, ProjectType, ScopeType, SquareFootage, EstimatedCost, Status)
    VALUES ('Vega Logistics HQ - Drywall & Gypsum', 'Commercial', 'Drywall & Gypsum', 6800, 578000.00, 'In_Progress')
    RETURNING ProjectID INTO p3;
  INSERT INTO LeadSubmissions (ProjectID, CompanyName, ContactName, ContactEmail, ContactPhone, PostalCode)
    VALUES (p3, 'Vega Logistics', 'Priya Vega', 'p.vega@vegalogistics.com', '514-221-9900', 'H4C 1G7');
END $$;
