import { pool, query } from '../config/database';

export type ScopeType =
  | 'Drywall & Gypsum'
  | 'Flooring & Epoxy'
  | 'Premium Painting'
  | 'Complete Interior Turnkey';

export type ProjectType = 'Commercial' | 'Residential';

export interface RenovationLead {
  companyName?:   string;
  contactName:    string;
  contactEmail:   string;
  contactPhone:   string;
  postalCode:     string;
  squareFootage:  number;
  projectType:    ProjectType;
  scopeSelection: ScopeType;
  ipAddress?:     string;
  userAgent?:     string;
}

export interface LeadResult {
  leadId:        string;
  projectId:     string;
  estimatedCost: number;
  ratePerSqft:   number;
}

// Fetch the active cost rate from DB (falls back to hardcoded default)
const fetchRate = async (
  scope: ScopeType,
  type:  ProjectType,
  client: ReturnType<typeof pool.connect> extends Promise<infer T> ? T : never
): Promise<number> => {
  const res = await (client as any).query(
    `SELECT RatePerSqft FROM CostRates
     WHERE ScopeType = $1
       AND ProjectType = $2
       AND EffectiveFrom <= CURRENT_DATE
       AND (EffectiveTo IS NULL OR EffectiveTo >= CURRENT_DATE)
     ORDER BY EffectiveFrom DESC LIMIT 1`,
    [scope, type]
  );
  if (res.rows.length > 0) return parseFloat(res.rows[0].rateperSqft);

  // Safe fallback rates (CAD per sqft)
  const fallback: Record<ScopeType, Record<ProjectType, number>> = {
    'Drywall & Gypsum':          { Commercial: 85,  Residential: 70  },
    'Flooring & Epoxy':          { Commercial: 110, Residential: 90  },
    'Premium Painting':          { Commercial: 65,  Residential: 55  },
    'Complete Interior Turnkey': { Commercial: 195, Residential: 165 },
  };
  return fallback[scope][type];
};

export const createLeadWithProject = async (lead: RenovationLead): Promise<LeadResult> => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // 1. Fetch dynamic rate
    const ratePerSqft   = await fetchRate(lead.scopeSelection, lead.projectType, client as any);
    const estimatedCost = Math.round(lead.squareFootage * ratePerSqft * 100) / 100;

    // 2. Insert project
    const projectRes = await client.query(
      `INSERT INTO RenovationProjects
         (ProjectName, ProjectType, ScopeType, SquareFootage, EstimatedCost, Status)
       VALUES ($1, $2, $3, $4, $5, 'Lead_Generated')
       RETURNING ProjectID`,
      [
        `${lead.contactName} — ${lead.scopeSelection}`,
        lead.projectType,
        lead.scopeSelection,
        lead.squareFootage,
        estimatedCost,
      ]
    );
    const projectId = projectRes.rows[0].projectid;

    // 3. Insert lead
    const leadRes = await client.query(
      `INSERT INTO LeadSubmissions
         (ProjectID, CompanyName, ContactName, ContactEmail, ContactPhone,
          PostalCode, Notes, IPAddress, UserAgent)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING LeadID`,
      [
        projectId,
        lead.companyName || null,
        lead.contactName,
        lead.contactEmail,
        lead.contactPhone,
        lead.postalCode,
        `Requested scope: ${lead.scopeSelection}`,
        lead.ipAddress || null,
        lead.userAgent || null,
      ]
    );

    await client.query('COMMIT');

    return {
      leadId:        leadRes.rows[0].leadid,
      projectId,
      estimatedCost,
      ratePerSqft,
    };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

export const getAllLeads = async () => {
  const res = await query(`SELECT * FROM v_lead_overview LIMIT 200`);
  return res.rows;
};

export const getRevenueSummary = async () => {
  const res = await query(`SELECT * FROM v_revenue_summary`);
  return res.rows;
};

export const updateProjectStatus = async (projectId: string, status: string) => {
  const res = await query(
    `UPDATE RenovationProjects SET Status = $1 WHERE ProjectID = $2 RETURNING *`,
    [status, projectId]
  );
  return res.rows[0];
};
