# Interior Renovation Platform

Full-stack platform for capturing renovation leads, generating instant estimates, and managing the project pipeline.

## Tech Stack

| Layer     | Technology                              |
|-----------|-----------------------------------------|
| Frontend  | React 18 + TypeScript + Tailwind CSS    |
| Backend   | Node.js + Express + TypeScript          |
| Database  | PostgreSQL 14+                          |

---

## Quick Start

### 1. Database

```bash
# Create the database
createdb interior_reno

# Run the schema (creates tables, enums, indexes, seed data)
psql interior_reno < backend/schema.sql
```

### 2. Backend

```bash
cd backend

# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env — set DATABASE_URL and FRONTEND_URL

# Run in development (hot-reload)
npm run dev

# Build for production
npm run build && npm start
```

Server starts at **http://localhost:5000**

### 3. Frontend

```bash
cd frontend
npm install
npm run dev   # Vite dev server at http://localhost:3000
```

---

## API Reference

| Method | Endpoint                       | Description                      |
|--------|--------------------------------|----------------------------------|
| POST   | /api/leads                     | Submit a new lead + get estimate |
| GET    | /api/leads                     | Fetch all leads (admin)          |
| GET    | /api/leads/summary             | Revenue funnel summary           |
| PATCH  | /api/projects/:id/status       | Update project status            |
| GET    | /api/health                    | Health check                     |

### POST /api/leads — Request body

```json
{
  "contactName":    "Sarah Tremaine",
  "contactEmail":   "sarah@tremainegroup.ca",
  "contactPhone":   "514-882-3301",
  "postalCode":     "H3A 2T5",
  "squareFootage":  4200,
  "projectType":    "Commercial",
  "scopeSelection": "Complete Interior Turnkey",
  "companyName":    "Tremaine Group"
}
```

### POST /api/leads — Response

```json
{
  "success": true,
  "message": "Lead registered and estimate generated.",
  "data": {
    "leadId":        "uuid",
    "projectId":     "uuid",
    "estimatedCost": 819000,
    "ratePerSqft":   195
  }
}
```

---

## Database Schema

```
RenovationProjects     — project records with status tracking
LeadSubmissions        — contact info linked to a project
CostRates              — dynamic pricing per scope + project type
v_lead_overview        — joined view (leads + projects)
v_revenue_summary      — funnel summary grouped by status
```

Pricing is loaded dynamically from the `CostRates` table.  
Update rates at any time without redeploying:

```sql
INSERT INTO CostRates (ScopeType, ProjectType, RatePerSqft, EffectiveFrom)
VALUES ('Complete Interior Turnkey', 'Commercial', 210.00, '2026-06-01');
```

---

## Rate Limiting

The `/api/leads` endpoint is rate-limited to **10 requests per IP per 15 minutes**.  
For production, swap the in-memory map in `middleware.ts` with a Redis-backed limiter (e.g. `rate-limiter-flexible`).

---

## Project Structure

```
interior-reno-platform/
├── backend/
│   ├── schema.sql                        ← Run this first
│   ├── .env.example                      ← Copy to .env
│   ├── package.json
│   ├── tsconfig.json
│   └── src/
│       ├── server.ts                     ← Entry point
│       ├── config/database.ts            ← PG pool
│       ├── models/leadModel.ts           ← DB queries
│       ├── controllers/leadController.ts ← Route handlers + validation
│       ├── middleware/middleware.ts       ← Logger, rate limiter, error handler
│       └── routes/api.ts                 ← Route definitions
└── frontend/
    └── src/components/
        ├── EstimateFunnel.tsx            ← Multi-step lead form
        ├── BeforeAfterSlider.tsx         ← Project comparison slider
        └── AdminDashboard.jsx            ← Internal lead management UI
```
