import { Router } from 'express';
import {
  handleLeadSubmission,
  handleGetLeads,
  handleGetSummary,
  handleUpdateStatus,
} from '../controllers/leadController';
import { rateLimiter } from '../middleware/middleware';

const router = Router();

// Lead routes
router.post('/leads',                  rateLimiter, handleLeadSubmission);
router.get('/leads',                               handleGetLeads);
router.get('/leads/summary',                       handleGetSummary);

// Project routes
router.patch('/projects/:id/status',               handleUpdateStatus);

// Health check
router.get('/health', (_req, res) => res.json({ status: 'ok', timestamp: new Date().toISOString() }));

export default router;
