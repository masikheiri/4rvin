import { Pool, PoolConfig } from 'pg';

const config: PoolConfig = {
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }
    : false,
  max: 20,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
};

export const pool = new Pool(config);

// Graceful shutdown
process.on('SIGINT',  () => pool.end());
process.on('SIGTERM', () => pool.end());

export const query = <T = any>(text: string, params?: any[]) =>
  pool.query<T>(text, params);
