import { useState, useEffect } from "react";

const SEED_LEADS = [
  { leadid: "1", contactname: "Sarah Tremaine",  contactemail: "sarah@tremainegroup.ca",       companyname: "Tremaine Group",    scopetype: "Complete Interior Turnkey", projecttype: "Commercial",  squarefootage: 4200, estimatedcost: 819000, status: "Proposal_Accepted", submittedat: "2026-05-20T10:23:00Z", postalcode: "H3A 2T5" },
  { leadid: "2", contactname: "Marcus Okafor",   contactemail: "marcus.okafor@gmail.com",      companyname: null,                scopetype: "Flooring & Epoxy",          projecttype: "Residential", squarefootage: 2100, estimatedcost: 189000, status: "Estimate_Sent",    submittedat: "2026-05-21T14:05:00Z", postalcode: "H2X 1Y3" },
  { leadid: "3", contactname: "Priya Vega",      contactemail: "p.vega@vegalogistics.com",     companyname: "Vega Logistics",    scopetype: "Drywall & Gypsum",          projecttype: "Commercial",  squarefootage: 6800, estimatedcost: 578000, status: "In_Progress",      submittedat: "2026-05-19T09:00:00Z", postalcode: "H4C 1G7" },
  { leadid: "4", contactname: "Jin-ho Park",     contactemail: "jinho.park@parkrealty.ca",     companyname: "Park Realty",       scopetype: "Premium Painting",          projecttype: "Commercial",  squarefootage: 3300, estimatedcost: 214500, status: "Lead_Generated",   submittedat: "2026-05-23T08:12:00Z", postalcode: "H1Y 2W4" },
  { leadid: "5", contactname: "Amara Diallo",    contactemail: "amara.d@hotmail.com",          companyname: null,                scopetype: "Complete Interior Turnkey", projecttype: "Residential", squarefootage: 1800, estimatedcost: 297000, status: "Completed",        submittedat: "2026-05-10T11:30:00Z", postalcode: "H3K 1P2" },
  { leadid: "6", contactname: "Claude Fortier",  contactemail: "cfortier@fortier-arch.com",    companyname: "Fortier Arch.",     scopetype: "Drywall & Gypsum",          projecttype: "Commercial",  squarefootage: 5100, estimatedcost: 433500, status: "In_Review",        submittedat: "2026-05-22T16:44:00Z", postalcode: "H2Y 1C6" },
  { leadid: "7", contactname: "Nadia Rousseau",  contactemail: "nadia.rousseau@nrdesign.ca",   companyname: "NR Design Studio",  scopetype: "Flooring & Epoxy",          projecttype: "Residential", squarefootage: 980,  estimatedcost: 88200,  status: "Cancelled",        submittedat: "2026-05-15T13:20:00Z", postalcode: "H4A 3J9" },
];

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string }> = {
  Lead_Generated:    { label: "Lead",      color: "#6366f1", bg: "#eef2ff" },
  Estimate_Sent:     { label: "Estimated", color: "#0891b2", bg: "#ecfeff" },
  In_Review:         { label: "In Review", color: "#d97706", bg: "#fffbeb" },
  Proposal_Accepted: { label: "Accepted",  color: "#059669", bg: "#ecfdf5" },
  In_Progress:       { label: "Active",    color: "#7c3aed", bg: "#f5f3ff" },
  Completed:         { label: "Done",      color: "#16a34a", bg: "#f0fdf4" },
  Cancelled:         { label: "Cancelled", color: "#dc2626", bg: "#fef2f2" },
};

const SCOPE_ICONS: Record<string, string> = {
  "Drywall & Gypsum":          "🧱",
  "Flooring & Epoxy":          "🏢",
  "Premium Painting":          "🎨",
  "Complete Interior Turnkey": "⭐",
};

const fmt = (n: number) =>
  "$" + Math.round(n).toLocaleString("en-CA") + " CAD";

const fmtDate = (s: string) =>
  new Date(s).toLocaleDateString("en-CA", { month: "short", day: "numeric", year: "numeric" });

export default function AdminDashboard() {
  const [leads]       = useState(SEED_LEADS);
  const [filter, setFilter] = useState("ALL");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<typeof SEED_LEADS[0] | null>(null);
  const [tab, setTab]     = useState("leads");

  const filtered = leads.filter(l => {
    const matchStatus = filter === "ALL" || l.status === filter;
    const q = search.toLowerCase();
    const matchSearch = !q ||
      l.contactname.toLowerCase().includes(q) ||
      l.contactemail.toLowerCase().includes(q) ||
      (l.companyname ?? "").toLowerCase().includes(q);
    return matchStatus && matchSearch;
  });

  const totalPipeline = leads
    .filter(l => !["Cancelled","Completed"].includes(l.status))
    .reduce((s, l) => s + l.estimatedcost, 0);
  const totalWon      = leads.filter(l => l.status === "Completed").reduce((s,l)=>s+l.estimatedcost,0);
  const newThisWeek   = leads.filter(l => l.status === "Lead_Generated").length;
  const convRate      = Math.round(leads.filter(l=>l.status==="Completed").length / leads.length * 100);

  const scopeCounts = leads.reduce((acc, l) => {
    acc[l.scopetype] = (acc[l.scopetype]||0) + 1; return acc;
  }, {} as Record<string,number>);

  const statusCounts = leads.reduce((acc,l)=>{
    acc[l.status]=(acc[l.status]||0)+1; return acc;
  },{} as Record<string,number>);

  return (
    <div style={{ fontFamily: "'DM Sans', system-ui, sans-serif", background: "#f8f7f4", minHeight: "100vh", padding: "0" }}>

      {/* Top bar */}
      <div style={{ background: "#1a1f2e", color: "#fff", padding: "14px 28px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#d97706" }}></div>
          <span style={{ fontSize: 12, letterSpacing: "0.15em", fontWeight: 500 }}>RENOVEX INTERIORS</span>
          <span style={{ fontSize: 11, color: "#64748b", marginLeft: 8 }}>/ Admin</span>
        </div>
        <div style={{ display: "flex", gap: 20 }}>
          {["leads","pipeline","analytics"].map(t => (
            <button key={t} onClick={()=>setTab(t)} style={{
              background: "none", border: "none", cursor: "pointer",
              fontSize: 11, letterSpacing: "0.1em", padding: "4px 0",
              color: tab===t ? "#d97706" : "#94a3b8",
              borderBottom: tab===t ? "1px solid #d97706" : "1px solid transparent",
              textTransform: "uppercase",
            }}>{t}</button>
          ))}
        </div>
      </div>

      <div style={{ padding: "28px 28px 0" }}>

        {/* KPI row */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 24 }}>
          {[
            { label: "Pipeline Value",  val: fmt(totalPipeline), sub: "Active + review" },
            { label: "Revenue Won",     val: fmt(totalWon),      sub: "Completed projects" },
            { label: "New Leads",       val: newThisWeek,        sub: "Pending estimate" },
            { label: "Conversion Rate", val: convRate+"%",       sub: "Lead → completed" },
          ].map(k => (
            <div key={k.label} style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 10, padding: "16px 18px" }}>
              <div style={{ fontSize: 10, letterSpacing: "0.14em", color: "#94a3b8", marginBottom: 6 }}>{k.label.toUpperCase()}</div>
              <div style={{ fontSize: 22, fontWeight: 600, color: "#1a1f2e", lineHeight: 1 }}>{k.val}</div>
              <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 4 }}>{k.sub}</div>
            </div>
          ))}
        </div>

        {/* LEADS TAB */}
        {tab === "leads" && (
          <div style={{ display: "grid", gridTemplateColumns: selected ? "1fr 320px" : "1fr", gap: 16 }}>
            <div style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 10, overflow: "hidden" }}>
              {/* Toolbar */}
              <div style={{ padding: "14px 18px", borderBottom: "0.5px solid #e2e8f0", display: "flex", gap: 10, alignItems: "center" }}>
                <input
                  placeholder="Search name, email, company…"
                  value={search}
                  onChange={e=>setSearch(e.target.value)}
                  style={{ flex: 1, padding: "7px 12px", border: "0.5px solid #e2e8f0", borderRadius: 6, fontSize: 12, outline: "none", background: "#f8f7f4" }}
                />
                <select value={filter} onChange={e=>setFilter(e.target.value)} style={{ padding: "7px 10px", border: "0.5px solid #e2e8f0", borderRadius: 6, fontSize: 12, background: "#f8f7f4", cursor: "pointer" }}>
                  <option value="ALL">All statuses</option>
                  {Object.entries(STATUS_CONFIG).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}
                </select>
              </div>

              {/* Table */}
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                <thead>
                  <tr style={{ background: "#f8f7f4" }}>
                    {["Contact","Scope","Type","Sqft","Estimate","Status","Date"].map(h=>(
                      <th key={h} style={{ padding: "10px 16px", textAlign: "left", fontSize: 10, letterSpacing: "0.1em", color: "#94a3b8", fontWeight: 500, borderBottom: "0.5px solid #e2e8f0" }}>{h.toUpperCase()}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(l => {
                    const sc = STATUS_CONFIG[l.status];
                    return (
                      <tr key={l.leadid} onClick={()=>setSelected(selected?.leadid===l.leadid?null:l)}
                        style={{ cursor: "pointer", borderBottom: "0.5px solid #f1f5f9", background: selected?.leadid===l.leadid ? "#fffbf5" : "transparent" }}>
                        <td style={{ padding: "11px 16px" }}>
                          <div style={{ fontWeight: 500, color: "#1a1f2e" }}>{l.contactname}</div>
                          <div style={{ color: "#94a3b8", fontSize: 11 }}>{l.companyname ?? l.contactemail}</div>
                        </td>
                        <td style={{ padding: "11px 16px", color: "#374151" }}>{SCOPE_ICONS[l.scopetype]} {l.scopetype}</td>
                        <td style={{ padding: "11px 16px", color: "#64748b" }}>{l.projecttype}</td>
                        <td style={{ padding: "11px 16px", color: "#374151", fontFamily: "monospace" }}>{l.squarefootage.toLocaleString()}</td>
                        <td style={{ padding: "11px 16px", color: "#1a1f2e", fontWeight: 500, fontFamily: "monospace" }}>{fmt(l.estimatedcost)}</td>
                        <td style={{ padding: "11px 16px" }}>
                          <span style={{ background: sc.bg, color: sc.color, fontSize: 10, padding: "3px 9px", borderRadius: 4, letterSpacing: "0.08em", fontWeight: 500 }}>{sc.label}</span>
                        </td>
                        <td style={{ padding: "11px 16px", color: "#94a3b8" }}>{fmtDate(l.submittedat)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {filtered.length === 0 && (
                <div style={{ padding: "40px", textAlign: "center", color: "#94a3b8", fontSize: 12 }}>No leads match your filter.</div>
              )}
            </div>

            {/* Detail panel */}
            {selected && (
              <div style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 10, padding: 20, alignSelf: "start" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
                  <span style={{ fontSize: 10, letterSpacing: "0.14em", color: "#94a3b8" }}>LEAD DETAIL</span>
                  <button onClick={()=>setSelected(null)} style={{ background:"none",border:"none",cursor:"pointer",color:"#94a3b8",fontSize:16 }}>×</button>
                </div>
                <div style={{ fontSize: 15, fontWeight: 600, color: "#1a1f2e", marginBottom: 2 }}>{selected.contactname}</div>
                <div style={{ fontSize: 11, color: "#94a3b8", marginBottom: 16 }}>{selected.companyname ?? "Individual"}</div>

                {[
                  ["Email",    selected.contactemail],
                  ["Postal",   selected.postalcode],
                  ["Scope",    `${SCOPE_ICONS[selected.scopetype]} ${selected.scopetype}`],
                  ["Type",     selected.projecttype],
                  ["Sqft",     selected.squarefootage.toLocaleString() + " sqft"],
                  ["Estimate", fmt(selected.estimatedcost)],
                  ["Submitted",fmtDate(selected.submittedat)],
                ].map(([k,v])=>(
                  <div key={k as string} style={{ display:"flex", justifyContent:"space-between", padding:"7px 0", borderBottom:"0.5px solid #f1f5f9", fontSize:12 }}>
                    <span style={{ color:"#94a3b8" }}>{k}</span>
                    <span style={{ color:"#1a1f2e", fontWeight:500, maxWidth:160, textAlign:"right" }}>{v}</span>
                  </div>
                ))}

                <div style={{ marginTop: 20, display:"flex", flexDirection:"column", gap:8 }}>
                  <div style={{ fontSize:10, letterSpacing:"0.12em", color:"#94a3b8", marginBottom:4 }}>UPDATE STATUS</div>
                  {Object.entries(STATUS_CONFIG).map(([k,v])=>(
                    <button key={k} style={{
                      padding:"7px 12px", border:"0.5px solid", borderColor: selected.status===k ? v.color : "#e2e8f0",
                      borderRadius:6, background: selected.status===k ? v.bg : "transparent",
                      color: selected.status===k ? v.color : "#64748b",
                      fontSize:11, cursor:"pointer", textAlign:"left",
                    }}>{v.label}</button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* PIPELINE TAB */}
        {tab === "pipeline" && (
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
            {Object.entries(STATUS_CONFIG).map(([status, cfg]) => {
              const group = leads.filter(l=>l.status===status);
              const total = group.reduce((s,l)=>s+l.estimatedcost,0);
              return (
                <div key={status} style={{ background:"#fff", border:"0.5px solid #e2e8f0", borderRadius:10, overflow:"hidden" }}>
                  <div style={{ padding:"12px 16px", borderBottom:"0.5px solid #e2e8f0", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ background:cfg.bg, color:cfg.color, fontSize:10, padding:"3px 9px", borderRadius:4, letterSpacing:"0.08em", fontWeight:500 }}>{cfg.label.toUpperCase()}</span>
                    <span style={{ fontSize:11, color:"#94a3b8", fontFamily:"monospace" }}>{group.length} · {total>0?fmt(total):"—"}</span>
                  </div>
                  {group.length === 0
                    ? <div style={{ padding:"20px 16px", fontSize:11, color:"#c4c4c4", fontStyle:"italic" }}>No projects</div>
                    : group.map(l=>(
                      <div key={l.leadid} style={{ padding:"10px 16px", borderBottom:"0.5px solid #f8f7f4" }}>
                        <div style={{ fontWeight:500, fontSize:12, color:"#1a1f2e" }}>{l.contactname}</div>
                        <div style={{ fontSize:11, color:"#94a3b8" }}>{SCOPE_ICONS[l.scopetype]} {l.scopetype} · {fmt(l.estimatedcost)}</div>
                      </div>
                    ))
                  }
                </div>
              );
            })}
          </div>
        )}

        {/* ANALYTICS TAB */}
        {tab === "analytics" && (
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
            <div style={{ background:"#fff", border:"0.5px solid #e2e8f0", borderRadius:10, padding:20 }}>
              <div style={{ fontSize:10, letterSpacing:"0.14em", color:"#94a3b8", marginBottom:16 }}>LEADS BY SCOPE</div>
              {Object.entries(scopeCounts).map(([scope, count]) => (
                <div key={scope} style={{ marginBottom:12 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, marginBottom:4 }}>
                    <span style={{ color:"#374151" }}>{SCOPE_ICONS[scope]} {scope}</span>
                    <span style={{ color:"#94a3b8" }}>{count}/{leads.length}</span>
                  </div>
                  <div style={{ height:4, background:"#f1f5f9", borderRadius:2, overflow:"hidden" }}>
                    <div style={{ height:"100%", width:`${count/leads.length*100}%`, background:"#d97706", borderRadius:2 }}></div>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ background:"#fff", border:"0.5px solid #e2e8f0", borderRadius:10, padding:20 }}>
              <div style={{ fontSize:10, letterSpacing:"0.14em", color:"#94a3b8", marginBottom:16 }}>STATUS DISTRIBUTION</div>
              {Object.entries(statusCounts).map(([status, count]) => {
                const cfg = STATUS_CONFIG[status];
                return (
                  <div key={status} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"7px 0", borderBottom:"0.5px solid #f8f7f4" }}>
                    <span style={{ background:cfg.bg, color:cfg.color, fontSize:10, padding:"2px 8px", borderRadius:4 }}>{cfg.label}</span>
                    <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                      <div style={{ width:80, height:4, background:"#f1f5f9", borderRadius:2, overflow:"hidden" }}>
                        <div style={{ height:"100%", width:`${count/leads.length*100}%`, background:cfg.color, borderRadius:2 }}></div>
                      </div>
                      <span style={{ fontSize:11, color:"#94a3b8", width:20, textAlign:"right" }}>{count}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div style={{ background:"#1a1f2e", borderRadius:10, padding:20, gridColumn:"1/-1" }}>
              <div style={{ fontSize:10, letterSpacing:"0.14em", color:"#64748b", marginBottom:16 }}>ESTIMATED PIPELINE — COMMERCIAL VS RESIDENTIAL</div>
              <div style={{ display:"flex", gap:32 }}>
                {["Commercial","Residential"].map(type=>{
                  const total = leads.filter(l=>l.projecttype===type).reduce((s,l)=>s+l.estimatedcost,0);
                  return (
                    <div key={type}>
                      <div style={{ fontSize:11, color:"#64748b", marginBottom:4 }}>{type}</div>
                      <div style={{ fontSize:26, fontWeight:600, color: type==="Commercial"?"#d97706":"#60a5fa", fontFamily:"monospace" }}>{fmt(total)}</div>
                      <div style={{ fontSize:11, color:"#475569", marginTop:2 }}>{leads.filter(l=>l.projecttype===type).length} projects</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        <div style={{ height: 32 }}></div>
      </div>
    </div>
  );
}
