import { Request, Response, NextFunction } from 'express';

// ── Simple request logger ───────────────────────────────────
export const requestLogger = (req: Request, res: Response, next: NextFunction) => {
  const start = Date.now();
  res.on('finish', () => {
    const ms = Date.now() - start;
    const color = res.statusCode >= 500 ? '\x1b[31m'
                : res.statusCode >= 400 ? '\x1b[33m'
                : '\x1b[32m';
    console.log(`${color}[${new Date().toISOString()}] ${req.method} ${req.path} ${res.statusCode} — ${ms}ms\x1b[0m`);
  });
  next();
};

// ── In-memory rate limiter (swap for Redis in production) ───
const ipMap = new Map<string, { count: number; resetAt: number }>();
const WINDOW_MS  = 15 * 60 * 1000; // 15 minutes
const MAX_HITS   = 10;

export const rateLimiter = (req: Request, res: Response, next: NextFunction) => {
  const ip  = req.ip ?? 'unknown';
  const now = Date.now();
  const rec = ipMap.get(ip);

  if (!rec || now > rec.resetAt) {
    ipMap.set(ip, { count: 1, resetAt: now + WINDOW_MS });
    return next();
  }

  rec.count += 1;
  if (rec.count > MAX_HITS) {
    return res.status(429).json({
      success: false,
      errors: ['Too many requests. Please wait 15 minutes before submitting again.'],
    });
  }
  next();
};

// ── Global error handler ────────────────────────────────────
export const errorHandler = (
  err: Error,
  _req: Request,
  res: Response,
  _next: NextFunction
) => {
  console.error('[Global Error]', err.stack);
  res.status(500).json({ success: false, errors: ['An unexpected error occurred.'] });
};
